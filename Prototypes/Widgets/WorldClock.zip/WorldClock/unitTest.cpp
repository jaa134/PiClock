#include <unistd.h>
#include <iostream>
#include <fstream>
#include "SystemUsageWidget.hpp"

#define CATCH_CONFIG_MAIN
#include "catch.hpp"

